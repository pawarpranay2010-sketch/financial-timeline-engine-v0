# ingestion/__init__.py
"""
Ingestion package (PDF/DOCX/CSV/XLSX parsing, chunking) -- NOT YET MIGRATED.

This package is scaffolding for a future migration module -- the directory
exists (per the target FinancialTimelineEngine architecture) so imports
like `from ingestion import ...` resolve cleanly and other packages can
already declare a dependency on it, but its logic has not been extracted
out of app.py yet.

Only `core/` has been migrated so far. This package will be filled in
during its own module-by-module migration pass (see README.md), at which
point app.py's relevant section will be replaced with imports from here,
exactly as already done for core/.
"""
