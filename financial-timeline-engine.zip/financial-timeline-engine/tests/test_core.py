# tests/test_core.py
"""
Unit tests for the `core` package. These run with plain `pytest` and do
NOT require Streamlit to be installed, since `core` isolates its only
Streamlit dependency behind `StreamlitSecretsProvider` /
`StreamlitSessionLogSink`, neither of which is exercised here.

Run with:  pytest tests/test_core.py -v
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import core
from core.config import EnvSecretsProvider, set_secrets_provider
from core.logging import InMemoryLogSink, ProviderEventLogger


def test_hash_text_is_stable_and_distinct():
    assert core.hash_text("hello") == core.hash_text("hello")
    assert core.hash_text("hello") != core.hash_text("world")
    assert core.hash_text(None) == core.hash_text("")


def test_cache_manager_computes_once():
    store = {}
    cache = core.CacheManager(store)
    calls = {"n": 0}

    def compute():
        calls["n"] += 1
        return "value"

    value1, hit1 = cache.get_or_compute("key", compute)
    value2, hit2 = cache.get_or_compute("key", compute)

    assert value1 == value2 == "value"
    assert hit1 is False
    assert hit2 is True
    assert calls["n"] == 1


def test_retry_succeeds_after_transient_failures():
    attempts = {"n": 0}

    def flaky():
        attempts["n"] += 1
        if attempts["n"] < 3:
            raise ValueError("transient")
        return "ok"

    assert core.retry(flaky, attempts=5, delay=0) == "ok"
    assert attempts["n"] == 3


def test_retry_reraises_after_exhausting_attempts():
    def always_fails():
        raise RuntimeError("permanent")

    try:
        core.retry(always_fails, attempts=2, delay=0)
        assert False, "expected RuntimeError to propagate"
    except RuntimeError as exc:
        assert str(exc) == "permanent"


def test_extract_json_handles_code_fence():
    assert core.extract_json('```json\n{"a": 1}\n```', dict) == {"a": 1}


def test_extract_json_handles_prose_wrapped_json():
    assert core.extract_json('Here is the JSON: {"a": 1} thanks', dict) == {"a": 1}


def test_extract_json_returns_empty_on_error_marker():
    assert core.extract_json("\u26a0\ufe0f provider error", dict) == {}
    assert core.extract_json("\u26a0\ufe0f provider error", list) == []


def test_extract_json_handles_arrays():
    assert core.extract_json("[1, 2, 3]", list) == [1, 2, 3]


def test_is_error_response_and_contains_error_marker():
    assert core.is_error_response("\u274c failed") is True
    assert core.is_error_response("all good") is False
    assert core.contains_error_marker("prefix \u26a0\ufe0f suffix") is True
    assert core.contains_error_marker("prefix suffix") is False


def test_provider_health_uses_injected_secrets_provider():
    set_secrets_provider(EnvSecretsProvider())
    os.environ["GROQ_API_KEY"] = "test-key"
    os.environ.pop("GOOGLE_API_KEY", None)
    os.environ.pop("OPENROUTER_API_KEY", None)

    health = core.get_provider_health()

    assert health["Groq"] is True
    assert health["Google AI Studio"] is False
    assert health["OpenRouter"] is False


def test_provider_event_logger_uses_injected_sink():
    sink = InMemoryLogSink()
    logger = ProviderEventLogger(sink=sink)

    logger.log("unit-test-stage", "Google AI Studio", "success")
    logger.log("unit-test-stage", "Groq", "failed", "timeout")

    entries = logger.recent(10)
    assert len(entries) == 2
    assert entries[0]["provider"] == "Google AI Studio"
    assert entries[0]["status"] == "success"
    assert entries[1]["detail"] == "timeout"


def test_engine_settings_defaults_match_original_hardcoded_values():
    settings = core.SETTINGS
    assert settings.primary_model == "google/gemini-2.0-flash-exp:free"
    assert settings.fallback_model == "meta-llama/llama-3.1-8b-instruct:free"
    assert settings.groq_models == (
        "openai/gpt-oss-20b",
        "openai/gpt-oss-120b",
        "llama-3.1-8b-instant",
    )
    assert settings.chunk_size == 10000
    assert settings.chunk_overlap == 500
    assert settings.merge_batch_size == 8


if __name__ == "__main__":
    import pytest
    raise SystemExit(pytest.main([__file__, "-v"]))
